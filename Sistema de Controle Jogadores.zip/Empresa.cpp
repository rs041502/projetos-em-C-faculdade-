#include "Empresa.hpp"




Empresa::Empresa()
{
}

Empresa::Empresa(string nomeTime, string nome, string dataNascimento, string nacionalidade, double salario_bruto, string data_Inicio_prof, int dia, int mes, int ano):Time( nomeTime,  nome,  dataNascimento,  nacionalidade,  salario_bruto,  data_Inicio_prof,  dia,  mes,  ano)
{
	
	this->nome = nome;
	this->dataNascimento = dataNascimento;
	this->nacionalidade = nacionalidade;
	set_salario_bruto(salario_bruto);
	set_data_Inicio_prof(data_Inicio_prof);
	setDia(dia);
	setMes(mes);
	setAno(ano);
}

string Empresa::consultaJogador()
{
	cout << "Digite o Nome do jogador" << endl;
	cin >> nome;

	stringstream frase;

	frase << "O nome do jogador eh: " << Jogador::nome << endl;
	frase << "A data de nascimento eh: " << Jogador::dataNascimento << endl;
	frase << "a idade do jogador eh:" << Jogador::CalcularIdade() << endl;
	frase << "O salario bruto do jogador eh: " << Jogador::get_salario_bruto() << endl;
	frase << "O salario liquido do jogador eh: " << Jogador::salarioLiquido() << endl;


	return frase.str();

	

	
	
}

void Empresa::listaJogadores()
{
	cout << "Jogadores que fazem parte da empresa" << endl;

	stringstream frase;
	frase << "o id do jogador eh " << Jogador::novoId() << endl;
	frase << "O nome do jogador eh: " << Jogador::nome << endl;
	frase << "A data de nascimento eh: " << Jogador::dataNascimento << endl;
	frase << "a idade do jogador eh:" << Jogador::CalcularIdade() << endl;
	frase << "A categoria eh : " << Categoria() << endl;
	frase << "A nacionalidade do jogador eh: " << nacionalidade << endl;

	cout << frase.str() << endl;

}


void Empresa::relatorioFinanceiro()
{
	stringstream frase;

	frase << "O valor pago de salario eh: " << Jogador::salario_bruto<< endl;
	frase << "O valor destinado ao INSS eh: " << INSS() << endl;
	frase << "O valor destinado ao imposto de renda eh " << ImpostoRenda() << endl;


	cout << frase.str() << endl;


}

double Empresa::INSS()
{
	if (salario_bruto <= 1100)
	{
		valorINSS = (salario_bruto * 0.075);

		return valorINSS;

	}
	else if (salario_bruto > 1100 && salario_bruto <= 2000)
	{

		valorINSS = (salario_bruto * 0.09);


		return valorINSS;

	}
	else if (salario_bruto > 2000 && salario_bruto <= 3100)
	{
		valorINSS = (salario_bruto * 0.12);


		return valorINSS;

	}
	else if (salario_bruto > 3100 && salario_bruto <= 4100)
	{
		valorINSS = (salario_bruto * 0.14);


		return valorINSS;

	}
	else
		valorINSS = (salario_bruto * 0.14);


	return valorINSS;
}


double Empresa::ImpostoRenda()
{

	if (salario_bruto <= 1100)
	{
		imposto = (salario_bruto * 0.0);

		return imposto;

	}
	else if (salario_bruto > 1100 && salario_bruto <= 2000)
	{

		imposto = (salario_bruto * 0.075);


		return imposto;

	}
	else if (salario_bruto > 2000 && salario_bruto <= 3100)
	{
		imposto = (salario_bruto * 0.15);


		return imposto;

	}
	else if (salario_bruto > 3100 && salario_bruto <= 4100)
	{
		imposto = (salario_bruto * 0.22);


		return imposto;

	}
	else
		imposto = (salario_bruto * 0.27);


	return imposto;

}