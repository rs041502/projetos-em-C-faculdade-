#pragma once
#include "Pessoa.hpp"
using namespace std;
#include <sstream>
#define ANO 2022
#define MES 12
#define DIA 05

class Jogador :
    public Pessoa
{
public:

    Jogador();
    Jogador(string nome, string dataNascimento, string nacionalidade, double salario_bruto, string data_Inicio_prof, int ano, int dia, int mes);

    void set_data_Inicio_prof(string data_Inicio_prof);
    void set_salario_bruto(double salario_bruto);
    void setDia(int dia);
    void setMes(int mes);
    void setAno(int ano);
    int getDia();
    int getMes();
    int getAno();


    string getdata_Inicio_prof();
    double get_salario_bruto();
   

    string Categoria();
    int CalcularIdade();
    void aposentadoria();
    double salarioLiquido();
    static int novoId();
    string Detalhes();

protected:

     static int id;
    string data_Inicio_prof;
    double salario_bruto;
    double salario_liquido;
    int anosContribuidos;
    int idade;
    int dia;
    int mes;
    int ano;
    int JogadorSeguinte();
};
