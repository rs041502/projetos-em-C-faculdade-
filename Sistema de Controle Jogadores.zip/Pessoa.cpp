#include "Pessoa.hpp"


Pessoa::Pessoa() {}
Pessoa::Pessoa(string nome, string dataNascimento, string nacionalidade)
{
	this->nome = nome;
	this->dataNascimento = dataNascimento;
	this->nacionalidade = nacionalidade;
}

void Pessoa::setNome(string nome)
{
	this->nome = nome;
}
void Pessoa::setDataNascimento(string dataNascimento)
{
	this->dataNascimento = dataNascimento;
}
void Pessoa::setNacionalidade(string nacionalidade)
{
	this->nacionalidade = nacionalidade;
}

string Pessoa::getNome()
{
	return nome;
}
string Pessoa::getDataNascimento()
{
	return dataNascimento;
}
string Pessoa::getNacionalidade()
{
	return nacionalidade;
}