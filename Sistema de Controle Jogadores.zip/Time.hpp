#pragma once
#include "Jogador.hpp"
#include <sstream>
class Time :
    public Jogador
{
public:

    Time() {};
    Time(string nomeTime,string nome, string dataNascimento, string nacionalidade, double salario_bruto, string data_Inicio_prof, int dia, int mes, int ano);
    void setNome(string nomeTime);
    string getNome();
    string relatorioGeral();
    string relatorioFinanceiro();
    static int novoIdTime();
    void visualizarTime();
   
protected:
    int static idTime;
    int TimeSeguinte();

private:
    
    string nomeTime;
    Jogador time[1];
    
};
