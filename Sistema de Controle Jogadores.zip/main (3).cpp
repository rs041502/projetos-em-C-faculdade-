
#include <iostream>
#include "Jogador.hpp"
#include "Time.hpp"
#include "Empresa.hpp"

//Trabalho Andrius Anselmi, Gregorio Pontim e Wagner


    int main()
    {

    
        Jogador j1("Joao", "25.11.09", "argentino", 1200, "12.04.09", 25, 11, 2009);
        cout << j1.Detalhes();
        j1.aposentadoria();

        cout << " " << endl;


        Jogador j2("Artur", "25.10.95", "brasileiro", 2500, "12.05.12", 25, 10, 1995);
        cout << j2.Detalhes();
        cout << " " << endl;


        Time t1("Inter", "Joao", "25.11.09", "argentino", 1200, "12.04.09", 25, 11, 2009);

        cout << t1.relatorioGeral();
        cout << t1.relatorioFinanceiro();
        t1.visualizarTime();

        cout << " " << endl;

        Time t2("Gremio", "Artur", "25.10.95", "brasileiro", 2500, "12.05.12", 25, 10, 1995);

        cout << t2.relatorioGeral();
        cout << t2.relatorioFinanceiro();
        t2.visualizarTime();


        Empresa e1("Inter", "Joao", "25.11.09", "argentino", 1200, "12.04.09", 25, 11, 2009);
        cout<< e1.consultaJogador()<<endl;
        e1.listaJogadores();
        e1.relatorioFinanceiro();

      Empresa e2("Gremio", "Artur", "25.10.95", "brasileiro", 2500, "12.05.12", 25, 10, 1995);
      cout<< e2.consultaJogador()<<endl;
      e2.listaJogadores();
      e2.relatorioFinanceiro();
      
    }

