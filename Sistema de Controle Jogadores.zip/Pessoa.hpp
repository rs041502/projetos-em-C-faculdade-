#pragma once
#include <iostream>
#include <sstream>
using namespace std;

class Pessoa
{
public:
	Pessoa();
	Pessoa(string nome, string dataNascimento, string nacionalidade);

	void setNome(string nome);
	void setDataNascimento(string dataNascimento);
	void setNacionalidade(string nacionalidade);

	

	string getNome();
	string getDataNascimento();
	string getNacionalidade();

protected:
	string nome;
	string dataNascimento;
	string nacionalidade;
};
