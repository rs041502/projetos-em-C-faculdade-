#pragma once
#include "Time.hpp"
#include <sstream>



using namespace std;
class Empresa :
    public Time
{
public:
    Empresa();
    Empresa(string nomeTime, string nome, string dataNascimento, string nacionalidade, double salario_bruto, string data_Inicio_prof, int dia, int mes, int ano);
    string consultaJogador();
    void listaJogadores();
    void relatorioFinanceiro();
    double INSS();
    double ImpostoRenda();
   
protected:
    
    double valorINSS;
    double imposto;
      
};
