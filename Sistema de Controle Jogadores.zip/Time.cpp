#include "Time.hpp"
#include "Jogador.hpp"


int Time::idTime = 0;



Time::Time(string nomeTime, string nome, string dataNascimento, string nacionalidade, double salario_bruto, string data_Inicio_prof, int dia, int mes, int ano)
    :Jogador(nome,  dataNascimento,  nacionalidade,  salario_bruto,  data_Inicio_prof,  dia,  mes,  ano)
{
    idTime = TimeSeguinte();
    this->nomeTime = nomeTime;
    this->nome = nome;
    this->dataNascimento = dataNascimento;
    this->nacionalidade = nacionalidade;
    set_salario_bruto(salario_bruto);
    set_data_Inicio_prof(data_Inicio_prof);
    setDia(dia);
    setMes(mes);
    setAno(ano);
}


void Time::setNome(string nomeTime)
{
    this->nomeTime = nomeTime;
}




string Time::getNome()
{
    return nomeTime;
}



string Time::relatorioGeral()
{
    stringstream frase;
    frase << "o id do time eh " << novoIdTime() << endl;
    frase << "O nome do time eh: " << nomeTime << endl;
    frase << "O nome do jogador eh: " << Jogador::nome << endl;
    frase << "A data de nascimento eh: " << Jogador::dataNascimento << endl;
    frase << "a idade do jogador eh:" << Jogador::CalcularIdade() << endl;
    frase << "A categoria eh : " << Jogador::Categoria() << endl;
    frase << "A nacionalidade do jogador eh: " << Jogador::nacionalidade << endl;

    return frase.str();
}

string Time::relatorioFinanceiro()
{
    stringstream frase;
    frase << "O nome do jogador eh: " << Jogador::nome << endl;
    frase << "O salario bruto do jogador eh: " << Jogador::get_salario_bruto() << endl;
    frase << "O salario liquido do jogador eh: " << Jogador::salarioLiquido() << endl;

    return frase.str();
}


int Time::novoIdTime()
{
    return idTime;
}

void Time::visualizarTime()
{
    for (int i = 0; i < sizeof(time) / sizeof(Jogador); i++)
    {
        cout << time[i].getNome() << " esta no time \n";
    }
}

int Time::TimeSeguinte()
{
    return ++Time::idTime;
}