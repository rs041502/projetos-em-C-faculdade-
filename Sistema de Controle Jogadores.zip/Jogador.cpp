#include "Jogador.hpp"

int Jogador::id = 0;

Jogador::Jogador() {}
Jogador::Jogador(string nome, string dataNascimento, string nacionalidade, double salario_bruto, string data_Inicio_prof, int dia, int mes, int ano) {
   
    id = JogadorSeguinte();
    this->nome = nome;
    this->dataNascimento = dataNascimento;
    this->nacionalidade = nacionalidade;
    this->salario_bruto = salario_bruto;
    this->data_Inicio_prof = data_Inicio_prof;
    this->ano = ano;
    this->dia = dia;
    this->mes = mes;

}

void Jogador::set_data_Inicio_prof(string data_Inicio_prof) {
    this->data_Inicio_prof = data_Inicio_prof;
}



void Jogador::set_salario_bruto(double salario_bruto) {
    this->salario_bruto = salario_bruto;
}

void Jogador::setDia(int dia)
{
    this->dia = dia;
}
void Jogador::setMes(int mes)
{
    this->mes = mes;
}
void Jogador::setAno(int ano)
{
    this->ano = ano;
}

int Jogador::getDia()
{
    return dia;
}
int Jogador::getMes()
{
    return mes;
}
int Jogador::getAno()
{
    return ano;
}

string Jogador::getdata_Inicio_prof()
{
    if (idade <= 16)
    {
        return "nao iniciou";
    }

    else {
        return data_Inicio_prof;
    }
}

double Jogador::get_salario_bruto() { return salario_bruto; }

int Jogador::novoId() { return id; }



void Jogador::aposentadoria() {

    int idadeApos = 65;
    int contribMin = 20;
    int idadeAtual = 0;
    int contribAtual = 0;

    if (idadeAtual >= idadeApos && contribAtual >= contribMin) {
        cout << "Parabéns, você está apto para aposentadoria!"
            << "\n";

    }
    else if (idadeAtual < idadeApos && contribAtual < contribMin)
        cout << " Faltam " << idadeApos - idadeAtual
        << " anos, para atingir a idade minima para aposentadoria! " << idadeApos
        << " anos "
        << "\n";
    cout << "Mais " << contribMin - contribAtual
        << " anos de contribuição, para atingir o tempo minimo necessario de "
        << contribMin << " anos"
        << "\n";
}

double Jogador::salarioLiquido()
{

    if (salario_bruto <= 1100)
    {
        salario_liquido = salario_bruto - (salario_bruto * 0.075);

        return salario_liquido;

    }
    else if (salario_bruto > 1100 && salario_bruto <= 2000)
    {

        salario_liquido = salario_bruto - (salario_bruto * 0.09) - (salario_bruto * 0.075);


        return salario_liquido;

    }
    else if (salario_bruto > 2000 && salario_bruto <= 3100)
    {
        salario_liquido = salario_bruto - (salario_bruto * 0.12) - (salario_bruto * 0.15);


        return salario_liquido;

    }
    else if (salario_bruto > 3100 && salario_bruto <= 4100)
    {
        salario_liquido = salario_bruto - (salario_bruto * 0.14) - (salario_bruto * 0.22);


        return salario_liquido;

    }
    else
        salario_liquido = salario_bruto - (salario_bruto * 0.14) - (salario_bruto * 0.27);


    return salario_liquido;

}

int Jogador::CalcularIdade()
{
    idade = ANO - ano;
    if (mes > MES || mes == MES && dia > DIA) {
        idade--;
    }

    return idade;

}



string Jogador::Categoria()
{
    if (idade <= 16)
    {
        return "base";

    }

    else if (idade > 16)
    {
        return "profissional";

    }



}

string Jogador::Detalhes()
{
    stringstream frase;
    frase << "o id do jogador eh " << novoId() << endl;
    frase << "O nome do jogador eh: " << nome << endl;
    frase << "A data de nascimento eh: " << dataNascimento << endl;
    frase << "a idade do jogador eh:" << CalcularIdade() << endl;
    frase << "A categoria eh : " << Categoria() << endl;
    frase << "A nacionalidade do jogador eh: " << nacionalidade << endl;
    frase << "O salario bruto do jogador eh: " << salario_bruto << endl;
    frase << "A data de inicio no profissional foi: " << getdata_Inicio_prof() << endl;
    frase << "O salario liquido do jogador eh de:  " << salarioLiquido() << endl;

    return frase.str();

}

int Jogador::JogadorSeguinte()
{
    return ++Jogador::id;
}